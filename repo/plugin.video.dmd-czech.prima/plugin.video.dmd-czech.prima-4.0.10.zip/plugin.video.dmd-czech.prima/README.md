# plugin.video.dmd-czech.prima

Plugin již není dále vyvíjen, byl nahrazen https://github.com/alladdin/plugin.video.primaplay
